/*
gsap.to(".box", { rotation: 360, x: 100, duration: 1 });
*/